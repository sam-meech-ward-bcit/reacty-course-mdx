import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const treeDatingProfiles = [
  {
    id: 0,
    name: 'Ash',
    age: 25,
    bio: 'I like to go on long walks on the beach and eat pizza.',
    image: 'https://unsplash.com/photos/tGTVxeOr_Rs/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjYzOTYwNDgw&force=true&w=640',
  },
  {
    name: 'Birch',
    age: 25,
    id: 1,
    bio: 'I am a birch tree',
    image: "https://unsplash.com/photos/tGTVxeOr_Rs/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjYzOTYwNDgw&force=true&w=640",
  },
  {
    name: 'Oak',
    age: 30,
    id: 2,
    bio: 'I am an oak tree',
    image: 'https://unsplash.com/photos/tGTVxeOr_Rs/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjYzOTYwNDgw&force=true&w=640',
  },
  {
    name: 'Pine',
    age: 35,
    id: 3,
    bio: 'I am a pine tree',
    image: 'https://unsplash.com/photos/tGTVxeOr_Rs/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjYzOTYwNDgw&force=true&w=640',
  },
  {
    name: 'Maple',
    age: 40,
    id: 4,
    bio: 'I am a maple tree',
    image: 'https://unsplash.com/photos/tGTVxeOr_Rs/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjYzOTYwNDgw&force=true&w=640',
  },
  {
    name: 'Walnut',
    age: 45,
    id: 5,
    bio: 'I am a walnut tree',
    image: 'https://unsplash.com/photos/tGTVxeOr_Rs/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjYzOTYwNDgw&force=true&w=640',
  }
]

const createMany = await prisma.tree.createMany({
  data: treeDatingProfiles,
  skipDuplicates: true, // Skip 'Bobo'
})
