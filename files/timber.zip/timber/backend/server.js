import express from 'express';

const app = express();

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

app.get('/api/trees', async (req, res) => {
  const trees = await prisma.tree.findMany()
  res.send(trees);
})

function treeResponse(tree, trees) {
  return {
    tree,
    nextTreeId: (tree.id + 1) % trees.length,
  }
}

app.get('/api/trees/random', (req, res) => {
  // get a random tree from prisma
  prisma.tree.findMany().then((trees) => {
    const randomTree = trees[Math.floor(Math.random() * trees.length)]
    res.send(treeResponse(randomTree, trees))
  })
})

app.get('/api/trees/:id', (req, res) => {
  prisma.tree.findMany().then((trees) => {
    const tree = trees.find(tree => tree.id === Number(req.params.id));
    res.send(treeResponse(tree, trees));
  })
})


const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log(`Listening on port ${port}...`);
});
