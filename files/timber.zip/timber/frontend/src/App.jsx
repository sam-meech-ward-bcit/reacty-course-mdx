import { useState, useEffect, useCallback, useContext, useReducer } from 'react'
import './App.css'
import TreeProfile from './components/TreeProfile'
import axios from 'axios'

import treeReducer from './treeReducer'


function App() {

  const [state, dispatch] = useReducer(treeReducer, {
    tree: null,
    error: null, 
    loading: null
  })

  const [size, setSize] = useState(0)

  useEffect(() => {

    const abortController = new AbortController()

    // listen for a resize on the window
    const resizeHandler = () => {
      console.log('resize')
      setSize(window.innerWidth)
    }
    window.addEventListener('resize', resizeHandler)

    ;(async () => {
      dispatch({type: 'loading'})
      try {
        const result = await axios.get("/api/trees/random", {
          signal: abortController.signal
        })
        dispatch({type: 'received_tree', tree: result.data})
      } catch (error) {
        if (axios.isCancel(error)) {
          return
        }
        dispatch({type: 'error', error})
      }
    })()

    return () => {
      abortController.abort()
      window.removeEventListener('resize', resizeHandler)
    }

  }, [])

  const handleLike = async (id) => {
    dispatch({type: 'loading'})
    try {
      const result = await axios.get('/api/trees/' + state.tree.nextTreeId)
      dispatch({type: 'received_tree', tree: result.data})
    } catch (error) {
      debugger
      dispatch({type: 'error', error})
    }
  }

  const handleDisLike = async (id) => {
    // tell the server we diusliked the tree
    dispatch({type: 'loading'})
    try {
      const result = await axios.get('/api/trees/' + state.tree.nextTreeId)
      dispatch({type: 'received_tree', tree: result.data})
    } catch (error) {
      debugger
      dispatch({type: 'error', error})
    }
  }

  return (
    <div className="App">

      <h1>Timber</h1>

      {size}

      {state.error && <h1>🤷‍♂️</h1>}

      {state.loading && <TreeProfile
          id={null}
          name="Loading..."
          age={"Loading..."}
          bio={"Loading..."}
          image={null}
          dispatch={dispatch}
          onLike={() => {}}
          onDisLike={() => {}}
        />}

      {state.tree &&

        <TreeProfile
          {...state.tree.tree}
          onLike={handleLike}
          onDisLike={handleDisLike}
        />
      }
      

    </div>
  )
}

export default App
