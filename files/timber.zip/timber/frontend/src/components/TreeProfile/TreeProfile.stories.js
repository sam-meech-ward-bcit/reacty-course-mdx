import TreeProfile from './index'

export default {
  title: 'TreeProfile',
  component: TreeProfile, 
}

const fakeData = {
  id: 0,
  name: 'Ash',
  age: 25,
  bio: 'I like to go on long walks on the beach and eat pizza.',
  image: 'https://unsplash.com/photos/tGTVxeOr_Rs/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjYzOTYwNDgw&force=true&w=640',
}

export const Primary = () => (
  <TreeProfile {...fakeData}></TreeProfile>
)
export const AnotherOne = () => (
  <TreeProfile {...fakeData}></TreeProfile>
)