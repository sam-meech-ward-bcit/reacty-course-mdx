export default function TreeProfile({id, name, age, bio, image, onDisLike, onLike}) {
  return (
    <div className="tree-profile">
      <button onClick={() => {
        onDisLike(id)
        dispatch({type: 'liketree', id: id})
      }}>❌</button>
      {image ?
      <img src={image} alt={name} />
      :
      <div className="tree-profile__image-placeholder"></div>
      }
      <button onClick={() => onLike(id)}>✅</button>
      <h2>{name}</h2>
      <p>{age} years old</p>
      <p>{bio}</p>
    </div>
  )
}
