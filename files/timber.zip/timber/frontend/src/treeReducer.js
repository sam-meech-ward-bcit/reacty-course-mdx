export default function treeReducer(state, action) {
  switch (action.type) {
    case 'loading':
      return {
        error: false,
        tree: null,
        loading: true
      }
    case 'received_tree':
      return {
        error: false,
        tree: action.tree,
        loading: false
      }
    case 'error':
      return {
        tree: null,
        error: action.error,
        loading: false
      }
    default:
      return state
  }

}