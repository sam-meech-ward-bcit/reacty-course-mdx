import CreateProductForm from "./index"

export default {
  title: "CreateProductForm",
  component: CreateProductForm,
  argTypes: {
    onSubmit: { action: 'create a product' },
  }
}

export const Default = (args) => <CreateProductForm {...args} />