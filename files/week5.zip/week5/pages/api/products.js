import { getProducts, createProduct } from '../../server/database'


async function postProduct(req, res) {
  const product = await createProduct(req.body)
  res.status(201).json(product)
}

export default async function handler(req, res) {
  if (req.method === 'POST') {
    // Process a POST request
    await postProduct(req, res)
  } else if (req.method === 'GET') {
    // Process a GET request
    const products = await getProducts()
    res.status(200).json(products)
  } else {
    // Handle any other HTTP method
    res.status(405).json({ message: 'Method not allowed' })
  }
}
