import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/router'

import CreateProductForm from '../components/CreateProductForm'

import axios from 'axios'

export default function CreateProduct() {

  const router = useRouter()

  const handleSubmit = async (product) => {
    console.log(product)

    try {
      // send this product to the backend
      const res = await axios.post('/api/products', product)
      // the backend needs to persist this data
      // navigate to the products page
      router.push('/products')
    } catch (error) {
      console.log(error)
      alert('Error creating product')
    }
  }

  return (
  <div className='flex flex-col items-center justify-center min-h-screen py-2'>
  <h1 className="text-3xl">Create Product</h1>


  <CreateProductForm onSubmit={handleSubmit} />

  <Link href="/">
    <a className='my-8 text-blue-500'>Home</a>
  </Link>
  </div>
  )
}