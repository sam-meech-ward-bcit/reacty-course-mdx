import { getProduct } from "../../server/database"

export default function Product({product}) {

  return (
    <div className='flex flex-col items-center justify-center min-h-screen py-2'>
      <h1 className="text-3xl">Product</h1>
      <div className='flex flex-col items-center justify-center w-full max-w-md'>
        <ul className='w-full'>
          <li key={product.id} className='flex items-center justify-between p-4 border-b border-gray-200'>
            <div className='flex flex-col items-start justify-start'>
              <span className='text-gray-700 font-bold'>{product.name}</span>
              <span className='text-gray-500 text-sm'>{product.price}</span>
              <span className='text-gray-500 text-sm'>{product.description}</span>
            </div>
          </li>
        </ul>
      </div>
    </div>
  )
}

export async function getServerSideProps(context) {
  // Everything in this funciton happesn on the server
  const product = await getProduct(context.params.productId)
  console.log(product)
  return {
    props: { product }, // will be passed to the page component as props
  }
}