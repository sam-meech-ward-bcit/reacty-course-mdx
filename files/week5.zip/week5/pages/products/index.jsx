import { getProducts } from '../../server/database';

import Link from 'next/link';

import axios from "axios"
import { useEffect, useState } from "react"

export default function Home({ products }) {

  // const [products, setProducts] = useState([])

  // useEffect(() => {
  //   ; (async () => {
  //     const res = await axios.get("/api/products")
  // console.log(res.data)
  //     setProducts(res.data)
  //   })()
  // }, [])

  useEffect(() => {
    console.log("some client env var", process.env.NEXT_PUBLIC_CLIENT_ENV_VAR)
  }, [])

  return (
    <div className='flex flex-col items-center justify-center min-h-screen py-2'>

      <h1 className="text-3xl">Products</h1>

      <div className='flex flex-col items-center justify-center w-full max-w-md'>
        <ul className='w-full'>
          {products.map((product) => (
            <li key={product.id} className='flex items-center justify-between p-4 border-b border-gray-200'>
              <div className='flex flex-col items-start justify-start'>
                <span className='text-gray-700 font-bold'>{product.name}</span>
                <span className='text-gray-500 text-sm'>{product.price}</span>
                <Link href={`/products/${product.id}`}>
                  <a>View</a>
                </Link>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

export async function getServerSideProps(context) {
  // Everything in this funciton happesn on the server
  const products = await getProducts()
  console.log(products)
  return {
    props: { products }, // will be passed to the page component as props
  }
}
