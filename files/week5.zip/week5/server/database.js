const products = [
  {
    id: 1,
    name: "Product 1",
    price: 100,
    description: "This is product 1",
  },
  {
    id: 2,
    name: "Product 2",
    price: 200,
    description: "This is product 2",
  }
]

// environtment variables should be used for:
//  1. sensitive data like passwords or keys (although, sometimes you have a "secrets manager" for that)
//  2. configuration data that is different for each environment (e.g. development, staging, production)

const databasePassword = process.env.DATABASE_PASSWORD

export async function createProduct(product) {
  const id = products.length + 1
  products.push({ id, ...product })
}

export async function getProducts() {
  console.log(databasePassword)
  return products
}
export async function getProduct(id) {
  return products.find(product => product.id == id)
}
